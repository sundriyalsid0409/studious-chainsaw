---
name: Autonomous Executive Intelligence
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#c0c1ff'
  on-tertiary: '#1000a9'
  tertiary-container: '#9699ff'
  on-tertiary-container: '#1d17b2'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 3rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Geist
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Geist
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Geist
    fontSize: 1.25rem
    fontWeight: '500'
    lineHeight: '1.35'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: -0.005em
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: '1.45'
    letterSpacing: 0.005em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.04em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: '1.15'
    letterSpacing: 0.06em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2.5rem
---

## Brand & Style

This design system embodies high-stakes executive management, autonomous recruitment intelligence, and private equity-grade algorithmic rigor. Designed specifically for C-suite operators, board candidates, and talent intelligence partners, the visual language balances high-density situational awareness with effortless institutional command. 

The aesthetic is precision-engineered command-center minimalism infused with architectural clarity. It eschews decorative flourishes in favor of structured data density, razor-sharp information hierarchy, and discreet micro-interactions. The experience feels like a sovereign intelligence terminal: authoritative, covert, unshakeably stable, and meticulously controlled. Every line, badge, and metric communicates calculated confidence and high fiduciary value.

## Colors

The color palette is calibrated exclusively for a dark-first terminal environment to reduce ocular fatigue during prolonged analytical sessions while emphasizing data variance.

- **Foundational Surfaces:** Deep obsidian and slate bases (`#030712`, `#0B0F17`, `#0F172A`, `#1E293B`) establish structural stability without pitch-black starkness. Sub-surfaces transition systematically through muted midnight tones to define layers of isolation and containment.
- **Primary Accent (Emerald - `#10B981`):** Represents positive algorithmic match confidence, verified status, high ATS readiness, and actionable pipeline execution. Use at full intensity only for focal confirmations, approvals, and top-tier metrics.
- **Secondary Accent (Cyan - `#06B6D4`):** Designates active telemetry, machine intelligence workflows, telemetry streams, and geographic filter matrices.
- **Tertiary Accent (Indigo - `#6366F1`):** Reserved for institutional context, headhunter communication layers, and cross-enterprise benchmarking.
- **Functional Warnings & Critical States:** High-visibility amber (`#F59E0B`) indicates pending approvals or compliance reviews; surgical crimson (`#EF4444`) isolates protocol rejections, misalignments, and system drop-offs.

## Typography

The typographic hierarchy is calibrated to handle complex tabular structures, real-time status monitors, and long-form dossier reviews. 

- **Geist (Headlines & Section Anchors):** Provides mechanical, clean authority with tightly packed counterforms and slight geometric squarishness. Keep letter tracking tight across all display and header tiers.
- **Hanken Grotesk (Body & Narrative Dossiers):** Delivers effortless human legibility across extensive candidate briefs, negotiation transcripts, and contextual intelligence summaries.
- **JetBrains Mono (Technical Labels, Data Tables, & Scoring Badges):** Provides tabular numeral alignment, precise coordinate labeling, ATS score metrics, and time-stamped activity feeds. All raw metrics, pipeline stages, currency figures, and geographic coordinates must use the label tier with uppercase transformations where specified.

## Layout & Spacing

The structural layout utilizes an adaptive 12-column grid engine optimized for ultra-dense data consumption and side-by-side terminal comparison.

- **Breakpoints:** 
  - Mobile (`< 768px`): Single-column stacked mode with persistent sticky action headers and horizontal swipe containers for stage pipelines.
  - Tablet (`768px - 1199px`): 8-column layout with collapsing metadata drawers and expandable table records.
  - Desktop (`>= 1200px`): Full 12-column command center with persistent split-pane capabilities (e.g., pipeline navigation alongside dynamic candidate dossiers).
- **Rhythm & Compaction:** The spacing architecture favors compactness over loose air. Padding inside cells and data blocks uses `space-xs` through `space-md` to maintain maximum above-the-fold visibility. Structural sections and analytical module boundaries leverage `space-xl` and `space-2xl` to prevent cognitive overload.

## Elevation & Depth

Visual hierarchy relies on low-contrast structural boundaries and subtle tonal stacking rather than heavy dropshadows.

- **Tonal Layering:** The primary background rests at `#030712`. Level 1 modules (panels, tables, pipelines) elevate to `#0B0F17`. Elevated interactive popovers, context menus, and inspection flyouts reside at `#111827`.
- **Low-Contrast Outlines:** Panels, chips, and table records employ a 1px boundary (`rgba(255, 255, 255, 0.08)`) to maintain surgical geometry. In active or focused states, the border intensifies to `rgba(16, 185, 129, 0.4)` or `rgba(6, 182, 212, 0.4)`.
- **Targeted Glows & Ambient Luminescence:** Elevate mission-critical elements (e.g., ATS scores >95%, urgent approval requests) using a restrained outer glow: `0px 0px 16px rgba(16, 185, 129, 0.15)`. Avoid global dropshadows across standard cards to preserve terminal flatness and absolute computational speed.

## Shapes

The shape system is crisp, industrial, and restrained (`roundedness: 1`). Containers, buttons, cards, and data cells feature slight corner breaks (4px / `0.25rem`) that soften the interface without diminishing its computational severity. 

Specialized exceptions:
- **Status Badges & Pills:** Filter selectors and metadata badges utilize fully rounded pill contours (`9999px`) to create an immediate categorical distinction against rectilinear data grids.
- **ATS Metric Rings & Mini-Gauges:** Radial, circular progress framing provides high contrast against surrounding angular tables.

## Components

### Buttons & Interactive Triggers
- **Primary (Approval/Commit):** Solid emerald background (`#10B981`) with dark text (`#030712`), 4px corner radius, bold tabular text. Hover produces a subtle cyan-tinted inner highlight and elevated luminance.
- **Secondary (Inspect/Filter):** Dark slate surface (`#1E293B`) with a 1px border (`rgba(255, 255, 255, 0.12)`) and muted text (`#F8FAFC`). Hover shifts border to `rgba(6, 182, 212, 0.5)`.
- **Ghost/Destructive:** Transparent background with muted crimson text (`#F87171`). Active click state flashes solid crimson with dark slate text.

### ATS Score Badges
- High-density capsules pairing a monospaced numerical rating with a status dot. 
- **>= 90% (Optimal):** Background `rgba(16, 185, 129, 0.1)`, text `#10B981`, border `rgba(16, 185, 129, 0.3)`.
- **70–89% (Viable):** Background `rgba(6, 182, 212, 0.1)`, text `#06B6D4`, border `rgba(6, 182, 212, 0.3)`.
- **< 70% (Deficient):** Background `rgba(239, 68, 68, 0.1)`, text `#EF4444`, border `rgba(239, 68, 68, 0.3)`.

### Geographic Filter Pills
- Fully rounded (`9999px`), low-profile pills featuring subtle region codes (e.g., `NYC // METRO`, `LON // EMEA`) set in JetBrains Mono. Selected pills trigger an emerald micro-border and cyan indicator beacon.

### Dense Data Tables
- Row height fixed at 40px for maximum vertical scan efficiency.
- Header rows pinned at top with background `#0B0F17`, uppercase label typography, and subtle bottom dividers (`#1E293B`).
- Hover state across rows triggers `#111827` surface fill with an emerald left indicator strip (2px width).

### Application Approval Pipeline
- Multi-stage horizontal workflow visualizer spanning: *Sourced*, *Autonomous Match*, *Executive Sign-Off*, *Direct Outreach*, *Board Review*.
- Connective nodes linked via ultra-thin vector traces (`1px`). Active stages pulse with a cyan luminescence; approved transitions reveal an emerald trailing rule.

### Input Fields & Search Bars
- Recessed slate background (`#0B0F17`) enclosed by a 1px outline (`rgba(255, 255, 255, 0.1)`). Focus state transitions outline directly to primary cyan (`#06B6D4`) without outward blur bleed. Inner typography uses monospaced hints for system query prompts.
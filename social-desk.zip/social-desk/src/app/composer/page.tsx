import Dashboard from '@/components/Dashboard';
export default function Page(){ return <Dashboard initialPage="Composer"/>; }

import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title:'Social Desk — AI social media manager', description:'Research, create, approve and schedule social content.' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en" className="dark"><body>{children}</body></html>; }

export type Platform = 'LinkedIn' | 'Instagram' | 'X' | 'YouTube Shorts';
export type PostStatus = 'Draft' | 'Needs approval' | 'Approved' | 'Scheduled' | 'Posted';
export const trends = [
 { id:'t1', title:'The rise of AI agents at work', category:'Technology', volume:'42.8K', change:'+128%', sentiment:'Positive', summary:'Teams are moving from AI chat tools to agents that complete multi-step workflows.' },
 { id:'t2', title:'Authenticity over polished content', category:'Creator economy', volume:'28.4K', change:'+86%', sentiment:'Positive', summary:'Audiences are rewarding human stories, behind-the-scenes moments and useful opinions.' },
 { id:'t3', title:'Zero-click content strategy', category:'Marketing', volume:'19.2K', change:'+64%', sentiment:'Rising', summary:'Brands are adapting content for discovery and value without relying on outbound clicks.' },
 { id:'t4', title:'Short-form educational video', category:'Video', volume:'16.7K', change:'+41%', sentiment:'Rising', summary:'Fast, focused explainers continue to perform across short-form video feeds.' }
];
export const accounts = [
 {id:'linkedin',name:'LinkedIn',handle:'Social Desk Studio',detail:'Professional network',color:'#69a8ff',connected:true},
 {id:'instagram',name:'Instagram',handle:'@socialdesk.studio',detail:'Visual storytelling',color:'#e78ab4',connected:true},
 {id:'x',name:'X',handle:'@socialdesk',detail:'Real-time conversation',color:'#dae2fd',connected:false},
 {id:'youtube',name:'YouTube',handle:'Social Desk',detail:'Shorts & video',color:'#ff7777',connected:false}
];
export const initialPosts = [
 {id:'p1',platform:'LinkedIn' as Platform,title:'Why AI agents are changing the way we work',content:'AI is moving beyond answering questions. The next wave is about getting meaningful work done. Here are three shifts teams should prepare for…',date:'2026-11-19',time:'09:30',status:'Scheduled' as PostStatus},
 {id:'p2',platform:'Instagram' as Platform,title:'A more human kind of content',content:'Less polish. More perspective. The content people remember feels like it came from a person, not a content machine. ✨',date:'2026-11-20',time:'12:00',status:'Needs approval' as PostStatus},
 {id:'p3',platform:'X' as Platform,title:'The zero-click shift',content:'Your content can deliver value before anyone clicks. Build for the feed, not just the funnel.',date:'2026-11-21',time:'10:15',status:'Draft' as PostStatus},
 {id:'p4',platform:'YouTube Shorts' as Platform,title:'AI agents in 30 seconds',content:'A quick explainer on what AI agents do, how they differ from chatbots, and where they fit into your workflow.',date:'2026-11-22',time:'17:00',status:'Posted' as PostStatus}
];
export const analytics = { impressions:'284.6K', engagement:'8.42%', followers:'+1,284', posts:'36', impressionChange:'+18.6%', engagementChange:'+2.4%', followerChange:'+12.8%', reachSeries:[34,49,42,66,53,76,61,88,72,94,78,100,83,91], impressionSeries:[30,45,37,58,49,72,62,83,69,94,78,100,85,92], engagementByPlatform:[{name:'Instagram',value:42},{name:'LinkedIn',value:31},{name:'YouTube',value:18},{name:'X',value:9}] };

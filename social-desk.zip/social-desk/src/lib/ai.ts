import { trends, type Platform } from '@/data/mock';
export async function researchTrends() { await new Promise(r=>setTimeout(r,700)); return trends; }
export async function generatePlatformDrafts(topic: string) {
 await new Promise(r=>setTimeout(r,1100));
 const clean = topic.trim() || 'The future of social media';
 const templates: Record<Platform,string> = {
  LinkedIn:`${clean} is changing how teams think, create and connect.\n\nThe opportunity isn't to do more for the sake of it. It's to make every interaction more useful.\n\nWhat's one shift you're paying attention to?`,
  Instagram:`A fresh perspective on ${clean} ✨\n\nSave this for later and share your take below.\n\n#SocialMedia #IdeasThatMatter #DigitalCulture`,
  X:`${clean}: the biggest opportunity is turning the noise into something genuinely useful. What's your take?`,
  'YouTube Shorts':`In 30 seconds: here's what you need to know about ${clean}. One clear idea, three useful takeaways, and a practical next step. Subscribe for more.`
 };
 return Object.entries(templates).map(([platform,content])=>({platform:platform as Platform,content,title:`${clean} — ${platform} edition`}));
}
export async function generateImagePlaceholder(prompt: string) { await new Promise(r=>setTimeout(r,850)); return {prompt:prompt || 'Editorial abstract gradient for a social post',label:'AI visual concept',style:'linear-gradient(135deg,#143a48 0%,#16765e 48%,#30385f 100%)'}; }

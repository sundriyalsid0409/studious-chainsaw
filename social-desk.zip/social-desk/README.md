# Social Desk

A Next.js App Router dashboard prototype for researching social trends, drafting platform-specific content, reviewing posts, scheduling a publishing calendar, and viewing sample analytics.

> **Source archive note:** The supplied Stitch ZIP contains six screens for an AI career-management platform, not social-media-manager screens. It includes one `DESIGN.md` design system but no Social Desk-specific screens. This implementation uses the supplied design tokens (dark navy surfaces, emerald/cyan accents, Geist, Hanken Grotesk, JetBrains Mono, spacing and compact radii) and builds the requested Social Desk product flows from the written brief.

## Stack
- Next.js 14 (App Router) + TypeScript
- Tailwind CSS
- Local mock data in `src/data/mock.ts`
- Replaceable AI simulation functions in `src/lib/ai.ts`

## Run locally

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Production build

```bash
npm run build
npm start
```

## Demo behavior
- Research refresh returns local sample trends.
- Composer creates LinkedIn, Instagram, X and YouTube Shorts drafts from local templates.
- Visual generation returns a styled placeholder and displays the prompt used.
- Posts enter the approval queue before they can be approved and scheduled.
- Connections use clearly labelled sample authorization dialogs. Never enter real passwords.
- Analytics and calendar use local sample data. No external API calls are made.

## Project structure

```text
src/
  app/                 App Router pages
  components/          Shared dashboard UI
  data/mock.ts         All sample topics, accounts, posts and metrics
  lib/ai.ts            Replaceable AI simulation functions
```

## Environment
No environment variables are required. `.env.example` is intentionally empty apart from comments for future integrations.
